export class ConstantesGenerales {
    public static readonly ordenDefault = 'SCORE_DESC';
    public static readonly anioDesc = 'ANIO_DESC';
    public static readonly anioAsc = 'ANIO_ASC';
    public static readonly numRadDesc = 'NUM_RADICADO_DESC';
    public static readonly numRadAsc = 'NUM_RADICADO_ASC';
    public static readonly fechaDesc = 'FECHA_DESC';
    public static readonly fechaAsc = 'FECHA_ASC';

    public static readonly tiposOrden = [
        {id: ConstantesGenerales.ordenDefault, nombre: 'Relevancia'},
        {id: ConstantesGenerales.anioDesc, nombre: 'Mayor Año'},
        {id: ConstantesGenerales.anioAsc, nombre: 'Menor Año'},
        {id: ConstantesGenerales.numRadDesc, nombre: 'Mayor número radicado'},
        {id: ConstantesGenerales.numRadAsc, nombre: 'Menor número radicado'},
        {id: ConstantesGenerales.fechaDesc, nombre: 'Mayor fecha radicado'},
        {id: ConstantesGenerales.fechaAsc, nombre: 'Menor fecha radicado'}
    ];
    public static readonly pageSizeDefault = 10;
    public static readonly maxHighlights = 10;
    public static readonly pageInit = 1;
    public static readonly API_COD_OK = '000';
}
