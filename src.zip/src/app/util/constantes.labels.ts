import {Injectable} from "@angular/core";

@Injectable({providedIn: 'root'})
export class ConstantesLabels {
    public readonly anoRad = 'Año de radicación';
    public readonly numeroRad = 'Número de radicación';
    public readonly fechaRad = 'Fecha de radicación';
    public readonly tema = 'Tema';
    public readonly subtema = 'Subtema';
    public readonly acciones = 'Acciones';
    public readonly noResultados = 'No hay conceptos que coincidan con tu búsqueda';
    public readonly coincidencias = 'Coincidencia(s)';
    public readonly descargar = 'Descargar';
    public readonly compartir = 'Compartir';
    public readonly resultados = 'Resultados encontrados';
    public readonly verDet = 'Ver Detalle';
    public readonly buscar = 'Buscar';
    public readonly aceptar = 'Aceptar';
    public readonly cancelar = 'Cancelar';
    public readonly limpiar = 'Limpiar';
    public readonly regresar = 'Volver';
    public readonly desde = 'Desde';
    public readonly hasta = 'Hasta';
    public readonly tituloBA = 'Búsqueda específica';
    public readonly tituloGeneral = 'Buscador de Conceptos Jurídicos';
    public readonly ayudaAnoRad = 'Año de radicado del expediente al que está relacionado el concepto jurídico';
    public readonly ayudaNumeroRad = 'Número de radicado del expediente al que está relacionado el concepto jurídico';
    public readonly ayudaFechaRad = 'Puedes escoger un rango en el que se encuentre la fecha de radicado';
    public readonly ayudaTema = 'Tema al que pertenece el concepto jurídico';
    public readonly msgError = 'Ha ocurrido un error, es posible un comportamiento inesperado en la aplicación';
    public readonly msgConfirmDownload = 'Seguro deseas descargar el archivo?';
    public readonly copiarLink = 'Vínculo copiado';
    public readonly copiar = 'Copiar';
    public readonly guiaUso = 'Guía de uso';
}
