import {Injectable} from "@angular/core";

@Injectable({providedIn: 'root'})
export class ConstantesRutas {
    readonly rutaLogoGOVCO = 'https://stgsicstatic.z13.web.core.windows.net/src/Logos-GOVCO/logogovco.webp';
    readonly rutaLogoPresidencia = 'https://stgsicstatic.z13.web.core.windows.net/src/Logos-Gobierno/Logo_Comercio_Horizontal.svg';
    readonly rutaLogoMin = 'https://stgsicstatic.z13.web.core.windows.net/src/Logos-Gobierno/Logo_Comercio.svg';
    readonly rutaLogoSIC = 'https://stgsicstatic.z13.web.core.windows.net/src/Logos-SIC/Logo_SIC_Horizontal.svg';
    readonly rutaLogoSICDark = 'https://stgsicstatic.z13.web.core.windows.net/src/Logos-SIC/Logo_SIC_Horizontal.svg';
    readonly rutaSearch = '/search';
    readonly rutaResults = '/search/results';
    readonly rutaDetail = '/search/detail';
}
