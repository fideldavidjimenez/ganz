import {NgModule} from '@angular/core';
import {HashLocationStrategy, LocationStrategy, NgOptimizedImage} from '@angular/common';
import {AppComponent} from './app.component';
import {AppRoutingModule} from './app-routing.module';
import {HeaderComponent} from './components/header/header.component';
import {FooterComponent} from './components/footer/footer.component';
import {AccessComponent} from './components/access/access.component';
import {BrowserModule} from "@angular/platform-browser";
import {FlexLayoutModule} from "@angular/flex-layout";
import {HttpClientModule} from "@angular/common/http";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {RECAPTCHA_V3_SITE_KEY, RecaptchaV3Module} from "ng-recaptcha";
import {environment} from "../environments/environment";
import {HelpSideBarComponent} from './components/help-side-bar/help-side-bar.component';
import {SidebarModule} from "primeng/sidebar";
import {ButtonModule} from "primeng/button";
import {LoaderComponent} from './components/loader/loader.component';
import {ProgressSpinnerModule} from "primeng/progressspinner";
import {DialogModule} from "primeng/dialog";
import {ConfirmationService, MessageService} from "primeng/api";

@NgModule({
    declarations: [
        AppComponent,
        HeaderComponent,
        FooterComponent,
        AccessComponent,
        HelpSideBarComponent,
        LoaderComponent
    ],
    imports: [
        AppRoutingModule,
        BrowserModule,
        FlexLayoutModule,
        HttpClientModule,
        BrowserModule,
        BrowserAnimationsModule,
        FormsModule,
        ReactiveFormsModule,
        RecaptchaV3Module,
        SidebarModule,
        ButtonModule,
        NgOptimizedImage,
        ProgressSpinnerModule,
        DialogModule
    ],
    providers: [
        {provide: LocationStrategy, useClass: HashLocationStrategy},
        {
            provide: RECAPTCHA_V3_SITE_KEY,
            useValue: environment.recaptcha.siteKey,
        },
        ConfirmationService,
        MessageService
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
}
