import {Component, OnInit} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {ConstantesRutas} from "../../util/constantes.rutas";

@Component({
    selector: 'app-footer',
    templateUrl: './footer.component.html',
    styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {

    /*htmlContent = '';
    urlFooter = 'http://10.20.100.39:8080/common-web/footer.html';
    urlSafe: SafeResourceUrl = '';*/

    constructor(private httpClient: HttpClient, public rutas: ConstantesRutas) {

    }

    ngOnInit() {

        /// this.urlSafe = this.sanitizer.bypassSecurityTrustResourceUrl(this.urlFooter);
        // let headers = new HttpHeaders();
        // headers = headers.set('Access-Control-Allow-Origin', '*');
        // headers = headers.set('Accept', '*/*');
        /*this.httpClient.get(this.urlFooter, {responseType: 'text'}).subscribe({
            next: value => {
                console.log(value);
                this.htmlContent = value;
            },
            error: error => {
                console.error(error);
            }
        });*/
    }
}
