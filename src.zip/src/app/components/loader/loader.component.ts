import {Component, OnInit} from '@angular/core';
import {ViewService} from "../../service/view.service";

@Component({
    selector: 'app-loader',
    templateUrl: './loader.component.html',
    styleUrls: ['./loader.component.scss']
})
export class LoaderComponent implements OnInit {

    constructor(public viewService: ViewService) {

    }

    ngOnInit() {

    }
}
