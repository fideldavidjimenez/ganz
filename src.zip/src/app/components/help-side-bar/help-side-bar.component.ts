import {Component} from '@angular/core';
import {Router} from "@angular/router";
import {OpenSearchService} from "../../service/open.search.service";
import {ViewService} from "../../service/view.service";
import {ConstantesRutas} from "../../util/constantes.rutas";

@Component({
    selector: 'app-help-side-bar',
    templateUrl: './help-side-bar.component.html',
    styleUrls: ['./help-side-bar.component.scss']
})
export class HelpSideBarComponent {

    visible = false;

    constructor(public router: Router, public viewService: ViewService, public constantesRutas: ConstantesRutas) {
    }

    onButtonClick() {
        this.visible = true;
    }

    validarRuta(rutaSearch: string): boolean {
        console.log(this.router.url, 'this.router.url');
        console.log(rutaSearch, 'rutaSearch');
        if (rutaSearch === this.constantesRutas.rutaDetail) {
            return this.router.url.includes(rutaSearch);
        } else {
            return this.router.url === rutaSearch;
        }
    }
}
