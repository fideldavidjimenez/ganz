import {Component, Inject} from '@angular/core';
import {DOCUMENT} from "@angular/common";
import {ConstantesRutas} from "../../util/constantes.rutas";
import {BehaviorSubject, Observable} from "rxjs";
import {ViewService} from "../../service/view.service";

@Component({
    selector: 'app-access',
    templateUrl: './access.component.html',
    styleUrls: ['./access.component.scss']
})
export class AccessComponent {

    scale: number;
    themes = [{
        id: 'light',
        path: '/assets/layout/styles/theme/lara-light-blue/theme.css',
        logo: this.constantesRutas.rutaLogoSIC
    }, {
        id: 'dark',
        path: '/assets/layout/styles/theme/lara-dark-blue/theme.css',
        logo: this.constantesRutas.rutaLogoSICDark
    }];
    theme = 'light';

    constructor(@Inject(DOCUMENT) private document: Document, private constantesRutas: ConstantesRutas, private viewService: ViewService) {

        const element = document.documentElement;
        const computedStyle = getComputedStyle(element);
        const fontSize = computedStyle.getPropertyValue('font-size');
        this.scale = fontSize ? parseInt(fontSize) : 16;
    }

    cambiarContraste() {
        const id = 'theme-css';
        const idLogo = 'logoSIC-header';
        let href = '';
        let themeLink = this.document.getElementById(id) as HTMLLinkElement;
        let logo = this.document.getElementById(idLogo) as HTMLImageElement;

        if (this.theme === 'dark') {
            this.setTheme('light');
        } else {
            this.setTheme('dark');
        }

        href = this.themes.find(t => t.id === this.theme)?.path || '';

        const cloneLinkElement = <HTMLLinkElement>themeLink.cloneNode(true);

        cloneLinkElement.setAttribute('href', href);
        cloneLinkElement.setAttribute('id', id + '-clone');

        themeLink.parentNode!.insertBefore(cloneLinkElement, themeLink.nextSibling);

        cloneLinkElement.addEventListener('load', () => {
            themeLink.remove();
            cloneLinkElement.setAttribute('id', id);

            logo.setAttribute('src', this.themes.find(t => t.id === this.theme)?.logo || '');
            this.viewService._themeSuject.next(this.theme);
        });

    }

    decrementScale() {
        this.scale--;
        document.documentElement.style.fontSize = this.scale + 'px';
    }

    incrementScale() {
        this.scale++;
        this.document.documentElement.style.fontSize = this.scale + 'px';
    }

    setTheme(theme: string) {
        this.theme = theme;
    }
}
