import {Component, ElementRef, ViewChild} from '@angular/core';
import {OpenSearchService} from "../../../service/open.search.service";
import {ConstantesLabels} from "../../../util/constantes.labels";
import {Router} from "@angular/router";
import {ViewService} from "../../../service/view.service";

@Component({
    selector: 'app-download-document',
    templateUrl: './download.document.component.html',
    styleUrls: ['./download.document.component.scss']
})
export class DownloadDocumentComponent {

    linkDescarga: HTMLAnchorElement;

    constructor(public service: OpenSearchService,
                public labels: ConstantesLabels,
                private router: Router,
                public viewService: ViewService) {

        this.linkDescarga = document.createElement('a');
    }

    public descargarPDF(idConcepto: number) {

        this.viewService.showLoader();

        this.service.consultarRutaPDF(idConcepto).subscribe({
            next: (value) => {

                if (value && value.cod_respuesta === '000' && value.url) {
                    this.service.consultarPDFBase64(value.url).subscribe({
                        next: (value) => {

                            const blob = new Blob([value], {
                                type: 'application/pdf',
                            });
                            const url = window.URL.createObjectURL(blob);

                            this.linkDescarga.href = url;
                            this.linkDescarga.download = 'concepto_juridico_' + idConcepto + '.pdf';
                            this.linkDescarga.click();

                        }, error: () => {
                            this.viewService.showGenericErrorToast();
                        }, complete: () => {
                            this.viewService.hideLoader();
                        }
                    });
                } else {
                    this.viewService.showGenericErrorToast();
                }

            }, error: () => {
                this.viewService.showGenericErrorToast();
            }, complete: () => {
                this.viewService.hideLoader();
            }
        });

    }

}
