import {Component, ElementRef, Inject, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {DOCUMENT} from "@angular/common";
import {Router} from "@angular/router";
import {OpenSearchService} from "../../../service/open.search.service";
import {ReCaptchaV3Service} from "ng-recaptcha";
import {ConstantesLabels} from "../../../util/constantes.labels";
import {RequestConceptoDTO} from "../../../dtos/request.concepto.dto";
import {ConstantesGenerales} from "../../../util/constantes.generales";
import * as moment from 'moment';
import {ConceptoDTO} from "../../../dtos/concepto.dto";
import {ViewService} from "../../../service/view.service";

@Component({
    selector: 'app-search',
    templateUrl: './search.component.html',
    styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {

    @ViewChild('divBA') divBA: ElementRef<HTMLDivElement> | undefined;
    anos: number[] = [];
    temas: { id: number, nombre: string }[] = [];
    layout: string = 'list';
    form: FormGroup;
    textQuery: string;
    mostrarBusquedaAvanzada = false;
    touchUI = false;

    constructor(private formBuilder: FormBuilder,
                @Inject(DOCUMENT) private document: Document,
                private router: Router,
                public service: OpenSearchService,
                public viewService: ViewService,
                private recaptchaV3Service: ReCaptchaV3Service,
                public labels: ConstantesLabels) {

        this.form = this.formBuilder.group({
            ano: [''],
            numero: ['', [Validators.maxLength(10), Validators.min(1)]],
            tema: [''],
            fechaInicial: [''],
            fechaFinal: ['']
        });

        this.textQuery = '';

    }

    ngOnInit(): void {

        this.service.resultados = undefined;
        this.service.concepto = {} as ConceptoDTO;

        this.consultarAnos();
        this.consultarTemas();

        this.init();

        if (window.innerWidth && window.innerWidth <= 820) {
            this.touchUI = true;
        }
    }

    private init(): void {
        this.service.reiniciar();
        this.textQuery = '';
        this.cerrar();
        this.viewService.hideLoader();
    }

    inicio(): void {
        this.init();
        this.router.navigate(['search']);
    }

    private consultarConceptos() {

        const req: RequestConceptoDTO = {
            orden: ConstantesGenerales.ordenDefault,
            tamanio_pagina: ConstantesGenerales.pageSizeDefault,
            num_pagina: ConstantesGenerales.pageInit,
            max_highlights: ConstantesGenerales.maxHighlights
        }

        if (this.textQuery) {
            req.consulta = this.textQuery;
        }

        if (this.form.value.ano) {
            req.anio = [Number(this.form.value.ano)];
        }

        if (this.form.value.fechaInicial) {
            req.fecha_desde = this.form.value.fechaInicial;
            req.fecha_desde = moment(req.fecha_desde as Date).format('yyyy-MM-DD');
        }

        if (this.form.value.fechaFinal) {
            req.fecha_hasta = this.form.value.fechaFinal;
            req.fecha_hasta = moment(req.fecha_hasta as Date).format('yyyy-MM-DD');
        }

        if (this.form.value.numero) {
            req.num_radicado = this.form.value.numero;
        }

        if (this.form.value.tema) {
            req.tema = [Number(this.form.value.tema)];
        }

        this.service.req = req;
        req.estadistica = true;
        this.service.buscar(req).then(value => {
            this.router.navigate(['search/results'], {onSameUrlNavigation: "reload"});
            this.mostrarBusquedaAvanzada = false;
        }).finally(() => {
            this.viewService.hideLoader();
        });

    }

    buscar(): void {

        this.viewService.showLoader();

        this.recaptchaV3Service.execute('importantAction')
            .subscribe({
                next: (token: string) => {
                    if (token) {
                        this.consultarConceptos();
                    }
                }, error: (e) => {
                    console.error('ha fallado el recaptcha', e);
                }
            });

    }

    private consultarAnos() {
        this.service.consultarAnos().subscribe(value => {
            this.anos = value;
        });
    }

    private consultarTemas() {
        this.service.consultarTemas().subscribe(value => {
            this.temas = value;
        });
    }

    cerrar() {
        this.form.reset();
        this.mostrarBusquedaAvanzada = false;
    }

    limpiar() {
        this.form.reset();
    }

    handleKeyUp($event: KeyboardEvent) {
        if ($event.code === 'Enter' || $event.code === 'NumpadEnter') {
            if (this.isDisableBuscar() === false) {
                this.buscar();
            }
        }
    }

    openBusquedaAvanzada() {
        this.mostrarBusquedaAvanzada = true;
    }

    closeBusquedaAvanzada() {
        this.mostrarBusquedaAvanzada = false;
    }

    clicBarraBusqueda() {
        if (this.validateFormBusquedaAvanzada()) {
            this.openBusquedaAvanzada();
        } else {
            this.closeBusquedaAvanzada();
        }
    }

    openBusquedaAvanzadaDesdeInput() {
        if (!this.textQuery || this.textQuery.length == 0) {
            this.openBusquedaAvanzada();
        }
    }

    isDisableBuscar(): boolean {
        return this.form.invalid || !this.validateFormBusquedaAvanzada();
    }

    get minDate(): Date {
        return this.form.get(['fechaInicial'])?.value;
    }

    get maxDate(): Date {
        return this.form.get(['fechaFinal'])?.value;
    }

    /**
     * Retorna falso si no existe ningún valor en el formulario de B.A.
     * @private
     */
    private validateFormBusquedaAvanzada(): boolean {

        if (this.form) {
            const formEmpty = !this.form.value.ano && !this.form.value.numero && !this.form.value.tema && !this.form.value.fechaInicial && !this.form.value.fechaFinal && !this.textQuery;

            return !formEmpty;
        }

        return false;

    }

    onShowBusquedaAvanzada($event: any): void {
        // console.log($event.overlay);
        if ($event.overlay) {
            if ($event.overlay.offsetTop < 0/*&& window.innerHeight <= 720*/) {
                $event.overlay.style.transform = 'translate(0,' + $event.overlay.clientHeight + 'px)';
                $event.overlay.style.transition = 'transform 1s';
            } else {
                $event.overlay.style.transform = '';
                $event.overlay.style.transition = '';
            }

            if (this.divBA?.nativeElement.offsetWidth) {
                $event.overlay.style.minWidth = this.divBA?.nativeElement.offsetWidth + 'px';
            }
        }
    }

    borrarBarraBusqueda(): void {
        this.textQuery = '';
    }
}
