import {AfterViewInit, Component, OnInit, ViewChild} from '@angular/core';
import {OpenSearchService} from "../../../service/open.search.service";
import {ConstantesLabels} from "../../../util/constantes.labels";
import {ActivatedRoute, Router} from "@angular/router";
import {ConceptoDTO} from "../../../dtos/concepto.dto";
import {DomSanitizer} from "@angular/platform-browser";
import {ConstantesGenerales} from "../../../util/constantes.generales";
import {ViewService} from "../../../service/view.service";
import {DownloadDocumentComponent} from "../download.document/download.document.component";
import {ShareComponent} from "../share/share.component";
import {NgxExtendedPdfViewerComponent, NgxExtendedPdfViewerService, PdfLoadedEvent, PdfLoadingStartsEvent} from "ngx-extended-pdf-viewer";

@Component({
    selector: 'app-detail',
    templateUrl: './detail.component.html',
    styleUrls: ['./detail.component.scss']
})
export class DetailComponent implements OnInit, AfterViewInit {

    concepto: ConceptoDTO = {} as ConceptoDTO;
    first = 0;
    rows = 1;
    rutaPDF = '';
    @ViewChild(DownloadDocumentComponent) downloadDocumentComponent: DownloadDocumentComponent | undefined;
    @ViewChild(ShareComponent) shareComponent: ShareComponent | undefined;
    @ViewChild('pdfViewer') pdfViewer?: NgxExtendedPdfViewerComponent;
    theme = '';
    loadingPDF = true;
    private styleViewer = {};

    constructor(public service: OpenSearchService,
                public labels: ConstantesLabels,
                private route: ActivatedRoute,
                private sanitizer: DomSanitizer,
                private router: Router,
                public viewService: ViewService,
                private pdfService: NgxExtendedPdfViewerService) {

        this.route.params.subscribe(value => {
            const id = Number(value['id']);
            if (id) {
                this.consultarConcepto(id);
            } else {
                this.regresar(); //this.pdfViewer
            }
        });

        this.viewService._themeSuject.subscribe({
            next: value => {
                this.theme = value;
            }
        });

    }

    ngOnInit() {
        // this.styleViewer = {'width': 'auto', 'height': '0px'};
    }

    ngAfterViewInit() {
        /*console.log(this.pdfViewer?.minHeight);
        console.log(this.pdfViewer?.height);
        if (this.pdfViewer) {
            this.styleViewer.
            this.pdfViewer.minHeight = '0';
            this.pdfViewer.height = '0';
        }
        console.log(this.pdfViewer?.minHeight);
        console.log(this.pdfViewer?.height);
        const x = document.querySelector('ngx-extended-pdf-viewer .zoom');
        x?.setAttribute('style', 'display: none;');
        console.log(x);*/
    }

    consultarConcepto(idConcepto: number) {

        if (this.service.concepto.id_concepto && this.service.concepto.id_concepto === idConcepto) {
            this.concepto = this.service.concepto;
            this.consultarRutaPDF();
        } else {
            this.service.consultarConcepto(idConcepto).subscribe({
                next: (value) => {
                    if (value && value.cod_respuesta === ConstantesGenerales.API_COD_OK) {
                        this.concepto = value;
                        this.service.concepto = value;

                        this.consultarRutaPDF();
                    } else {
                        this.regresar();
                    }
                }, error: () => {
                    this.regresar();
                }
            });

        }

    }

    private consultarRutaPDF(): void {
        if (!this.concepto.id_concepto) {
            return;
        }
        this.service.consultarRutaPDF(this.concepto.id_concepto).subscribe(res => {
            if (res && res.cod_respuesta === ConstantesGenerales.API_COD_OK) {
                this.concepto.rutaPDF = res.url;
                this.rutaPDF = this.concepto.rutaPDF + '';
            }
        });
    }

    onPageChange($event: any) {
        this.first = $event.first;
        this.rows = $event.rows;
    }

    regresar() {
        this.service.concepto = {} as ConceptoDTO;
        this.router.navigate(['search/results']);
    }

    confirmDescargarPDF(idConcepto?: number) {

        if (!idConcepto) {
            return;
        }

        this.viewService.confirmationService.confirm({
            message: this.labels.msgConfirmDownload,
            dismissableMask: true,
            closeOnEscape: true,
            acceptLabel: 'Sí',
            rejectLabel: 'Cerrar',
            accept: () => {
                this.downloadDocumentComponent?.descargarPDF(idConcepto);
            }
        });
    }

    openModalCompartir(concepto: ConceptoDTO) {
        this.shareComponent?.share(concepto);
    }

    pdfStartLoading($event: PdfLoadingStartsEvent) {
        // debugger;
        this.loadingPDF = true;
        /*const containerLoader = document.querySelector('div#outerContainer');
        if (containerLoader) {
            // containerLoader.innerHTML = '' + containerLoader.innerHTML;
        }
        debugger;*/
    }

    pdfLoaded($event: PdfLoadedEvent) {
        this.loadingPDF = false;
        // this.styleViewer = {'min-height': '90vh', 'width': 'auto', 'height': '100%'};
        this.pdfService.scrollPageIntoView(1, {top: '0%'});
        /*if (this.pdfViewer) {
            this.pdfViewer.minHeight = '100';
            this.pdfViewer.height = '100';
        }*/
        //const x = document.querySelector('ngx-extended-pdf-viewer .zoom');
        // x?.setAttribute('style', 'display: block;');
    }

    pdfError($event: Error) {
        this.loadingPDF = false;
        this.viewService.showErrorToast('Error cargando el PDF');
    }
}
