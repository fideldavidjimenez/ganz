import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {SearchRoutingModule} from './search-routing.module';
import {SearchComponent} from './search/search.component';
import {ButtonModule} from 'primeng/button';
import {OverlayPanelModule} from 'primeng/overlaypanel';
import {DropdownModule} from 'primeng/dropdown';
import {ReactiveFormsModule} from '@angular/forms';
import {InputTextareaModule} from 'primeng/inputtextarea';
import {CalendarModule} from 'primeng/calendar';
import {MessageModule} from 'primeng/message';
import {InputTextModule} from 'primeng/inputtext';
import {KeyFilterModule} from 'primeng/keyfilter';
import {TooltipModule} from 'primeng/tooltip';
import {DataViewModule} from "primeng/dataview";
import {ToolbarModule} from "primeng/toolbar";
import {FlexLayoutModule} from "@angular/flex-layout";
import {AccordionModule} from "primeng/accordion";
import {ResultsComponent} from './results/results.component';
import {TableModule} from "primeng/table";
import {PaginatorModule} from "primeng/paginator";
import {SelectButtonModule} from "primeng/selectbutton";
import {InputMaskModule} from "primeng/inputmask";
import {PanelModule} from "primeng/panel";
import {CheckboxModule} from "primeng/checkbox";
import {DetailComponent} from './detail/detail.component';
import {DividerModule} from "primeng/divider";
import {CarouselModule} from "primeng/carousel";
import {ConfirmDialogModule} from "primeng/confirmdialog";
import {ToastModule} from "primeng/toast";
import {DialogModule} from "primeng/dialog";
import {DownloadDocumentComponent} from './download.document/download.document.component';
import {ShareComponent} from './share/share.component';
import {NgxExtendedPdfViewerModule} from "ngx-extended-pdf-viewer";
import {ProgressSpinnerModule} from "primeng/progressspinner";
import {BlockUIModule} from "primeng/blockui";


@NgModule({
    declarations: [
        SearchComponent,
        ResultsComponent,
        DetailComponent,
        DownloadDocumentComponent,
        ShareComponent
    ],
    imports: [
        CommonModule,
        SearchRoutingModule,
        ButtonModule,
        OverlayPanelModule,
        DropdownModule,
        ReactiveFormsModule,
        InputTextareaModule,
        CalendarModule,
        MessageModule,
        InputTextModule,
        KeyFilterModule,
        TooltipModule,
        DataViewModule,
        ToolbarModule,
        FlexLayoutModule,
        AccordionModule,
        TableModule,
        PaginatorModule,
        SelectButtonModule,
        InputMaskModule,
        PanelModule,
        CheckboxModule,
        DividerModule,
        CarouselModule,
        ConfirmDialogModule,
        ToastModule,
        DialogModule,
        NgxExtendedPdfViewerModule,
        ProgressSpinnerModule,
        BlockUIModule
    ]
})
export class SearchModule {
}
