import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {SearchComponent} from './search/search.component';
import {DetailComponent} from "./detail/detail.component";
import {ResultsComponent} from "./results/results.component";

const routes: Routes = [
    {
        path: '', component: SearchComponent, children: [
            {path: 'results', component: ResultsComponent},
            {path: 'detail/:id', component: DetailComponent}
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class SearchRoutingModule {
}
