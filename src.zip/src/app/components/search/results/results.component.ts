import {Component, OnInit, ViewChild} from '@angular/core';
import {OpenSearchService} from "../../../service/open.search.service";
import {ConstantesLabels} from "../../../util/constantes.labels";
import {ConceptoDTO} from "../../../dtos/concepto.dto";
import {Router} from "@angular/router";
import {ConstantesGenerales} from "../../../util/constantes.generales";
import {RequestConceptoDTO} from "../../../dtos/request.concepto.dto";
import {Table} from "primeng/table";
import {ViewService} from "../../../service/view.service";
import {DownloadDocumentComponent} from "../download.document/download.document.component";
import {ShareComponent} from "../share/share.component";


@Component({
    selector: 'app-results',
    templateUrl: './results.component.html',
    styleUrls: ['./results.component.scss']
})
export class ResultsComponent implements OnInit {

    justifyOptions: string[] = ['list', 'grid'];
    layout: string = 'grid';
    orden: { id: string, nombre: string }[] = [];
    resultadosPorPagina = [10, 20, 50];

    ordenar = ConstantesGenerales.ordenDefault;
    resultadosPagina = ConstantesGenerales.pageSizeDefault;
    rows = ConstantesGenerales.pageSizeDefault;
    first = 0;
    filtrosDesplegados = [0, 1];
    req: RequestConceptoDTO = {} as RequestConceptoDTO;
    ordenEvent: { field?: string, order?: number } = {};

    @ViewChild(DownloadDocumentComponent) downloadDocumentComponent: DownloadDocumentComponent | undefined;
    @ViewChild(ShareComponent) shareComponent: ShareComponent | undefined;

    constructor(public service: OpenSearchService,
                public labels: ConstantesLabels,
                private router: Router,
                public viewService: ViewService) {
    }

    ngOnInit() {

        if (!this.service.req) {
            this.router.navigate(['search']);
        }

        this.init();

    }

    init() {

        if (window.innerWidth && window.innerWidth <= 820) {
            this.layout = 'grid';
            this.filtrosDesplegados = [];
        }

        this.orden = ConstantesGenerales.tiposOrden;

        if (this.service.req) {
            this.req = {...this.service.req};
        }
    }

    reset(): void {
        this.ordenar = ConstantesGenerales.ordenDefault;
        this.resultadosPagina = ConstantesGenerales.pageSizeDefault;
        this.rows = ConstantesGenerales.pageSizeDefault;
        this.first = 0;
        this.filtrosDesplegados = [0, 1];
        this.req = {} as RequestConceptoDTO;
    }

    openModalDetalle(aConcepto: ConceptoDTO) {

        if (aConcepto) {
            this.service.concepto = aConcepto;
            this.router.navigate(['search/detail', aConcepto.id_concepto]);
        }

    }

    filtrar(): void {

        if (this.service.req) {
            this.req = {...this.service.req};
        }

        if (this.service.selectedAnos.length > 0 && !this.req.anio) {
            this.req.anio = this.service.selectedAnos;
        }

        if (this.service.selectedTemas.length > 0 && !this.req.tema) {
            this.req.tema = this.service.selectedTemas;
        }

        this.service.buscar(this.req, true);

        this.first = 0;

    }

    onPageChange($event: any) {
        this.first = $event.first;
        this.rows = $event.rows;

        this.req.num_pagina = $event.page + ConstantesGenerales.pageInit;

        this.service.buscar(this.req, true);
    }

    get totalResultados(): number {
        return this.service.resultados?.num_resultados_total ? this.service.resultados?.num_resultados_total : 0;
    }

    get resultadosAnos(): { anio: number, cantidad: number }[] {
        return this.service.resultadosAno ? this.service.resultadosAno : [];
    }

    get resultadosTemas(): { id_tema: number, nombre: string, cantidad: number }[] {
        return this.service.resultadosTema ? this.service.resultadosTema : [];
    }

    get conceptos(): ConceptoDTO[] {
        return this.service.resultados?.resultados ? this.service.resultados?.resultados : [];
    }

    cambiarResultadosPagina() {
        this.rows = this.resultadosPagina;
        this.req.tamanio_pagina = this.resultadosPagina;

        this.service.buscar(this.req, true);
    }

    cambiarOrden() {
        this.first = 0;
        this.req.orden = this.ordenar;

        this.service.buscar(this.req, true);
    }

    resetOrder(mainTable: Table) {
        mainTable.reset();
        this.sort('');
    }

    sort(field: string) {

        if (this.ordenEvent.field && this.ordenEvent.field === field) {
            this.ordenEvent.order = this.ordenEvent.order ? this.ordenEvent.order * -1 : 1;
        } else if (field !== '') {
            this.ordenEvent = {field: field, order: 1};
        }

        switch (field) {
            case 'anio':
                this.req.orden = this.ordenEvent.order && this.ordenEvent.order > 0 ? ConstantesGenerales.anioAsc : ConstantesGenerales.anioDesc;
                break;
            case 'num_radicado':
                this.req.orden = this.ordenEvent.order && this.ordenEvent.order > 0 ? ConstantesGenerales.numRadAsc : ConstantesGenerales.numRadDesc;
                break;
            case 'fecha':
                this.req.orden = this.ordenEvent.order && this.ordenEvent.order > 0 ? ConstantesGenerales.fechaAsc : ConstantesGenerales.fechaDesc;
                break;
            default:
                this.req.orden = ConstantesGenerales.ordenDefault;
                this.ordenEvent = {};
                break;
        }

        this.service.buscar(this.req, true);
    }

    confirmDescargarPDF(idConcepto: number) {

        this.viewService.confirmationService.confirm({
            message: this.labels.msgConfirmDownload,
            dismissableMask: true,
            closeOnEscape: true,
            acceptLabel: 'Sí',
            rejectLabel: 'Cerrar',
            accept: () => {
                this.downloadDocumentComponent?.descargarPDF(idConcepto);
            }
        });
    }

    openModalCompartir(concepto: ConceptoDTO) {
        this.shareComponent?.share(concepto);
    }

}
