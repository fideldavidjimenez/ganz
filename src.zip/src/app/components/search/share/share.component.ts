import {Component, ElementRef, ViewChild} from '@angular/core';
import {OpenSearchService} from "../../../service/open.search.service";
import {ConstantesLabels} from "../../../util/constantes.labels";
import {Router} from "@angular/router";
import {ViewService} from "../../../service/view.service";
import {ConceptoDTO} from "../../../dtos/concepto.dto";
import {environment} from "../../../../environments/environment";

@Component({
    selector: 'app-share',
    templateUrl: './share.component.html',
    styleUrls: ['./share.component.scss']
})
export class ShareComponent {

    linkDescarga: HTMLAnchorElement;
    visible = false;
    rutaDetalleConcepto = '';
    @ViewChild('inputCopy') inputCopy: ElementRef<HTMLInputElement> | undefined;

    constructor(public service: OpenSearchService,
                public labels: ConstantesLabels) {

        this.linkDescarga = document.createElement('a');
    }

    share(concepto: ConceptoDTO) {
        this.visible = true;
        this.rutaDetalleConcepto = environment.rutaDetalleConcepto + '/' + concepto.id_concepto;
    }

    onShow() {
        this.copiar();
    }

    copiar() {
        this.inputCopy?.nativeElement.select();
        document.execCommand('copy');
    }
}
