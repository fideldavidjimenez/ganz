import {Component, OnInit} from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {ConstantesLabels} from "../../util/constantes.labels";
import {ConstantesRutas} from "../../util/constantes.rutas";

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

    // htmlContent = '';
    constructor(private httpClient: HttpClient, public rutas: ConstantesRutas) {
    }

    ngOnInit() {

        /*let headers = new HttpHeaders();
        headers = headers.set('Access-Control-Allow-Origin', '*');
        headers = headers.set('Accept', );
        this.httpClient.get('http://10.20.100.39:8080/common-web/header.html', {responseType: 'text'}).subscribe({
            next: value => {
                console.log(value);
                this.htmlContent = value;
            },
            error: error => {
                console.error(error);
            }
        });*/
    }
}
