import {Injectable} from '@angular/core';
import {ConstantesLabels} from "../util/constantes.labels";
import {ConfirmationService, MessageService} from "primeng/api";
import {BehaviorSubject} from "rxjs";


@Injectable({
    providedIn: 'root'
})
export class ViewService {

    public visibleLoader = false;

    _themeSuject = new BehaviorSubject<string>('light');

    constructor(public labels: ConstantesLabels,
                public confirmationService: ConfirmationService,
                public messageService: MessageService) {
    }

    showLoader(): void {
        this.visibleLoader = true;
    }

    hideLoader(): void {
        this.visibleLoader = false;
    }

    showGenericErrorToast(): void {
        this.messageService.add({severity: 'error', summary: '', detail: this.labels.msgError, life: 5000});
    }

    showErrorToast(message: string): void {
        this.messageService.add({severity: 'error', summary: '', detail: message, life: 5000});
    }

}
