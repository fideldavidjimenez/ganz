import {Injectable} from '@angular/core';
import {ConceptoDTO} from "../dtos/concepto.dto";
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {RespuestaConceptoDTO} from "../dtos/response.conceptos.dto";
import {RequestConceptoDTO} from "../dtos/request.concepto.dto";
import {ConstantesRutas} from "../util/constantes.rutas";
import {Observable} from "rxjs";
import {ViewService} from "./view.service";
import {environment} from "../../environments/environment";

@Injectable({
    providedIn: 'root'
})
export class OpenSearchService {

    resultados: RespuestaConceptoDTO | undefined;
    resultadosAno: { anio: number, cantidad: number } [] = [];
    resultadosTema: { id_tema: number, nombre: string, cantidad: number } [] = [];
    selectedAnos: number[] = [];
    selectedTemas: number[] = [];

    private _concepto: ConceptoDTO;
    req?: RequestConceptoDTO;

    constructor(private http: HttpClient, private rutas: ConstantesRutas, public viewService: ViewService) {
        this._concepto = {} as ConceptoDTO;
    }

    reiniciar(): void {
        this.resultados = undefined;
        this._concepto = {} as ConceptoDTO;
        this.selectedAnos = [];
        this.selectedTemas = [];
        this.req = undefined;
    }

    buscar(requestConceptoDTO: RequestConceptoDTO, filtrar = false): Promise<void> {

        requestConceptoDTO.estadistica = !filtrar;

        return new Promise<void>((resolve, reject) => {
            this.http.post<RespuestaConceptoDTO>(environment.rutaAPI + '/consultar', requestConceptoDTO)
                .subscribe({
                    next: (value) => {
                        this.resultados = value;
                        if (!filtrar) {
                            this.resultadosTema = this.resultados.resultados_tema;
                            this.resultadosAno = this.resultados.resultados_anio;
                            this.selectedAnos = [];
                            this.selectedTemas = [];
                        }
                        resolve();
                    }, error: (e) => {
                        console.error('error consultando conceptos');
                        reject();
                    }
                });
        });

    }

    isEmptyConceptos(): boolean {
        if (this.resultados) {
            return this.resultados.resultados.length === 0;
        }
        return true;
    }

    consultarConcepto(id: number): Observable<ConceptoDTO> {

        return this.http.get<ConceptoDTO>(environment.rutaAPI + '/concepto/' + id);

    }

    consultarAnos(): Observable<number[]> {

        return this.http.get<number[]>(environment.rutaAPI + '/anios');

    }

    consultarTemas(): Observable<{ id: number, nombre: string }[]> {

        return this.http.get<{ id: number, nombre: string }[]>(environment.rutaAPI + '/temas');

    }

    consultarRutaPDF(id: number): Observable<{ cod_respuesta?: string, url?: string }> {

        return this.http.get<{ cod_respuesta?: string, url?: string }>(environment.rutaAPI + '/documento/' + id);

    }

    consultarPDFBase64(url: string): Observable<Blob> {
        const headers = new HttpHeaders();
        headers.set('Access-Control-Allow-Origin', '*');
        return this.http.get(url, {responseType: 'blob', headers});
    }

    get concepto(): ConceptoDTO {
        return this._concepto;
    }

    set concepto(conceptoDTO: ConceptoDTO) {
        this._concepto = conceptoDTO;
    }
}
