import {RouterModule} from '@angular/router';
import {NgModule} from '@angular/core';

@NgModule({
    imports: [
        RouterModule.forRoot([
            {path: '', redirectTo: 'search', pathMatch: 'full'},
            {path: 'search', loadChildren: () => import('./components/search/search.module').then(m => m.SearchModule)},
            {path: '**', redirectTo: ''},
        ], {scrollPositionRestoration: 'enabled', anchorScrolling: 'enabled'})
    ],
    exports: [RouterModule]
})
export class AppRoutingModule {
}
