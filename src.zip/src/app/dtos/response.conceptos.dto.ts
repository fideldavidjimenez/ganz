import {ConceptoDTO} from "./concepto.dto";

export interface RespuestaConceptoDTO {
    cod_respuesta: string,
    num_resultados_total: number,
    num_resultados_actual: number,
    pagina_actual: number,
    total_paginas: number,
    tamanio_pagina: number,
    resultados_anio: { anio: number, cantidad: number } [],
    resultados_tema: { id_tema: number, nombre: string, cantidad: number } [],
    resultados: ConceptoDTO[]
}
