export interface ConceptoDTO {
    id_concepto?: number;
    anio: number;
    num_radicado: string;
    fecha: Date | string;
    tema?: { id: number, nombre: string };
    subtema?: string;
    palabras_clave: string[];
    highlights: string[];
    score?: number;
    rutaPDF?: string;
    cod_respuesta?: string;
    mensaje?: string;
}
