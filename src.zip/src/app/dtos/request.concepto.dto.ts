export interface RequestConceptoDTO {
    consulta?: string;
    anio?: number[];
    num_radicado?: string;
    fecha_desde?: Date | string;
    fecha_hasta?: Date | string;
    tema?: number[];
    orden?: string;
    tamanio_pagina: number,
    num_pagina: number,
    max_highlights: number,
    estadistica?: boolean
}
