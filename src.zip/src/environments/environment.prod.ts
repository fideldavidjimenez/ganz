export const environment = {
    production: true,
    config_file: 'prod',
    recaptcha: {
        siteKey: '6Lefu8goAAAAAHGR7eyOvkWtc5m0GecSWgIgFHB2',
    },
    rutaDetalleConcepto: 'https://buscadorconceptos.prod.sic.nuvu.cc/#/search/detail',
    rutaAPI: 'https://buscadorconceptos.prod.sic.nuvu.cc/api'
};
